export const firebaseConfig = {
    apiKey: "AIzaSyCoOOwPJlughS2CeKlrOq_dNH9X6tplblo",
    authDomain: "app-crude-d4949.firebaseapp.com",
    databaseURL: "https://app-crude-d4949-default-rtdb.firebaseio.com",
    projectId: "app-crude-d4949",
    storageBucket: "app-crude-d4949.firebasestorage.app",
    messagingSenderId: "731543982498",
    appId: "1:731543982498:web:c8dd97dde8ed81046da2fb"
};
