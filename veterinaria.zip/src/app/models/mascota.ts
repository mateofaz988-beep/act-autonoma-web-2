export interface Mascota {
    id: number;
    nombre: string;
    especie: string;
    historial: string;
}