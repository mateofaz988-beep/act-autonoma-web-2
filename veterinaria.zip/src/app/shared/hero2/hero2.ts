import { Component } from '@angular/core';

@Component({
  selector: 'app-hero2',
  imports: [],
  templateUrl: './hero2.html',
  styleUrl: './hero2.css',
})
export class Hero2 {

}
